#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
chmod +x ./drae-pet-frontend
exec ./drae-pet-frontend
