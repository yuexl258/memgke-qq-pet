#!/bin/sh
set -eu
cd -- "$(dirname -- "$0")"
chmod +x ./drae-pet-server
exec ./drae-pet-server
