@echo off
cd /d "%~dp0"
drae-pet-server.exe
pause
