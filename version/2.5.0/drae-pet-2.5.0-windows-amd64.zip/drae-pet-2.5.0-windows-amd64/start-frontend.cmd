@echo off
cd /d "%~dp0"
drae-pet-frontend.exe
pause
